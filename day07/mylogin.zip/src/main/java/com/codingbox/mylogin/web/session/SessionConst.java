package com.codingbox.mylogin.web.session;

public class SessionConst {
	// 상수만 정의
	public static final String LOGIN_MEMBER = "loginMember";
}
