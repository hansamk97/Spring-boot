package com.codingbox.mylogin.domain.login;

import lombok.Data;

@Data
public class LoginForm {
	private String loginId;
	private String password;
}











