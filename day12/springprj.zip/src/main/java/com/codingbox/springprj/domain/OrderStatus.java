package com.codingbox.springprj.domain;

public enum OrderStatus {
	ORDER, CANCEL;
}
