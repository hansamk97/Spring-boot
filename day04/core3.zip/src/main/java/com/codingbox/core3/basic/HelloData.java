package com.codingbox.core3.basic;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString
public class HelloData {
	private String username;
	private int age;
}
