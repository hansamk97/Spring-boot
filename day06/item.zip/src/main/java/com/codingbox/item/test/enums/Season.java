package com.codingbox.item.test.enums;

public enum Season {
	SPRING, SUMMER, FALL, WINTER;
}
